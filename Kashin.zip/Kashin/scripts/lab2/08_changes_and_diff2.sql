USE Stroika;
GO
DECLARE @j INT = 1; WHILE @j <= 20 BEGIN INSERT INTO dbo.Steps (steps_description) VALUES ('Step_S1_' + CAST(@j AS VARCHAR)); SET @j += 1; END
WHILE @j <= 40 BEGIN UPDATE dbo.Projects SET step_id = (@j % 12) + 1 WHERE id = (@j % 25) + 1; SET @j += 1; END
DELETE TOP (10) FROM dbo.Steps WHERE steps_description LIKE 'Step_S1_%';
GO
USE master;
BACKUP DATABASE Stroika TO DISK = 'C:\Kashin\Backup\S1_Diff2.bak' WITH DIFFERENTIAL, INIT, NAME = 'S1 Diff2', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\S1_Diff2.bak';
GO