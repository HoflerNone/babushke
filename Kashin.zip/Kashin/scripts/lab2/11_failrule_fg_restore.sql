USE master;
GO
ALTER DATABASE Stroika SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO

EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'xp_cmdshell', 1; RECONFIGURE;
GO

EXEC xp_cmdshell 'del "C:\Kashin\Data\Materials.ndf"';
GO
EXEC sp_configure 'xp_cmdshell', 0; RECONFIGURE;
EXEC sp_configure 'show advanced options', 0; RECONFIGURE;
GO


ALTER DATABASE Stroika SET ONLINE;
GO


BACKUP LOG Stroika TO DISK = 'C:\Kashin\Backup\Fail1_Tail.trn' WITH NO_TRUNCATE, INIT;
GO


RESTORE DATABASE Stroika 
FILEGROUP = 'FG_Materials' 
FROM DISK = 'C:\Kashin\Backup\Piecem_FG.bak' 
WITH NORECOVERY;
GO


RESTORE LOG Stroika FROM DISK = 'C:\Kashin\Backup\Piecem_Log.trn' WITH NORECOVERY;
GO


RESTORE LOG Stroika FROM DISK = 'C:\Kashin\Backup\Fail1_Tail.trn' WITH RECOVERY;
GO


USE Stroika;
GO
SELECT * FROM dbo.Materials 
GO