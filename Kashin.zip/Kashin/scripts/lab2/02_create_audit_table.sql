USE Stroika;
GO
CREATE TABLE dbo.Audit (
    AuditID       INT IDENTITY(1,1) NOT NULL,
    TableName     NVARCHAR(128)     NOT NULL,
    OperationType NVARCHAR(10)      NOT NULL,
    RecordID      INT               NULL,
    OldValue      NVARCHAR(MAX)     NULL,
    NewValue      NVARCHAR(MAX)     NULL,
    UserName      NVARCHAR(128)     NOT NULL,
    EventTime     DATETIME2(0)      NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT PK_Audit PRIMARY KEY CLUSTERED (AuditID) ON FG_Audit,
    CONSTRAINT CK_Audit_OperationType CHECK (OperationType IN (N'INSERT', N'UPDATE', N'DELETE'))
) ON FG_Audit;
GO