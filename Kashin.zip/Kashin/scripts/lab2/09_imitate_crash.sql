USE master;
GO

ALTER DATABASE Stroika SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO


EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'xp_cmdshell', 1; RECONFIGURE;
GO


EXEC xp_cmdshell 'del "C:\Kashin\Data\Projects.mdf"';
EXEC xp_cmdshell 'del "C:\Kashin\Log\Stroika.ldf"';
GO


EXEC sp_configure 'xp_cmdshell', 0; RECONFIGURE;
EXEC sp_configure 'show advanced options', 0; RECONFIGURE;
GO

ALTER DATABASE Stroika SET ONLINE;
GO

RESTORE DATABASE Stroika 
FROM DISK = 'C:\Kashin\Backup\S1_Full.bak' 
WITH REPLACE, NORECOVERY; 
GO


RESTORE DATABASE Stroika 
FROM DISK = 'C:\Kashin\Backup\S1_Diff2.bak' 
WITH RECOVERY;
GO


SELECT name, state_desc FROM sys.databases WHERE name = 'Stroika';
GO