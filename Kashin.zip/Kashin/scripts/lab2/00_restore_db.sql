USE master;
GO


RESTORE DATABASE Stroika
FROM DISK = 'C:\Kashin\Backup\S1_Full.bak'
WITH REPLACE, MOVE 'Projects' TO 'C:\Kashin\Data\Projects.mdf',
MOVE 'Steps' TO 'C:\Kashin\Data\Steps.ndf',
MOVE 'Materials' TO 'C:\Kashin\Data\Materials.ndf',
MOVE 'ProjectMaterials' TO 'C:\Kashin\Data\PMaterials.ndf',
MOVE 'Contractor' TO 'C:\Kashin\Data\Contractors.ndf',
MOVE 'Logs' TO 'C:\Kashin\Log\Stroika.ldf',
RECOVERY;
GO

SELECT name, state_desc FROM sys.databases WHERE name = 'Stroika';
GO