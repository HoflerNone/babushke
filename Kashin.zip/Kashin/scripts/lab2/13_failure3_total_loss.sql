USE master;
GO
BACKUP DATABASE Stroika TO DISK = 'C:\Kashin\Backup\Strat_Full2.bak' WITH INIT, NAME = 'Full2', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\Strat_Full2.bak';
GO
BACKUP LOG Stroika TO DISK = 'C:\Kashin\Backup\Fail3_Tail.trn' WITH NO_TRUNCATE, INIT;
GO
ALTER DATABASE Stroika SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO
EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'xp_cmdshell', 1; RECONFIGURE;
GO
EXEC xp_cmdshell 'del "C:\Kashin\Data\Projects.mdf"';
EXEC xp_cmdshell 'del "C:\Kashin\Log\Stroika.ldf"';
GO
EXEC sp_configure 'xp_cmdshell', 0; RECONFIGURE;
EXEC sp_configure 'show advanced options', 0; RECONFIGURE;
GO
RESTORE DATABASE Stroika FROM DISK = 'C:\Kashin\Backup\Strat_Full2.bak' WITH REPLACE, NORECOVERY;
GO
RESTORE LOG Stroika FROM DISK = 'C:\Kashin\Backup\Fail3_Tail.trn' WITH RECOVERY;
GO

USE Stroika;
GO
SELECT COUNT(*) AS TotalProjects FROM dbo.Projects;
GO