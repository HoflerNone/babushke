USE master;
GO

CREATE LOGIN admin_user WITH PASSWORD = 'AdminPass123!';
CREATE LOGIN foreman_user2 WITH PASSWORD = 'ForemanPass123!';
CREATE LOGIN foreman_user3 WITH PASSWORD = 'ForemanPass123!';
CREATE LOGIN client_user2 WITH PASSWORD = 'ClientPass123!';
CREATE LOGIN client_user3 WITH PASSWORD = 'ClientPass123!';
CREATE LOGIN proc_user2 WITH PASSWORD = 'ProcPass123!';
CREATE LOGIN proc_user3 WITH PASSWORD = 'ProcPass123!';
GO

USE Stroika;
GO

CREATE USER admin_user FOR LOGIN admin_user;
CREATE USER foreman_user2 FOR LOGIN foreman_user2;
CREATE USER foreman_user3 FOR LOGIN foreman_user3;
CREATE USER client_user2 FOR LOGIN client_user2;
CREATE USER client_user3 FOR LOGIN client_user3;
CREATE USER proc_user2 FOR LOGIN proc_user2;
CREATE USER proc_user3 FOR LOGIN proc_user3;
GO

ALTER USER admin_user FOR LOGIN admin_user;
ALTER USER foreman_user2 FOR LOGIN foreman_user2;
ALTER USER foreman_user3 FOR LOGIN foreman_user3;
ALTER USER client_user2 FOR LOGIN client_user2;
ALTER USER client_user3 FOR LOGIN client_user3;
ALTER USER proc_user2 FOR LOGIN proc_user2;
ALTER USER proc_user3 FOR LOGIN proc_user3;
GO


ALTER ROLE Admin ADD MEMBER admin_user;
ALTER ROLE Foreman ADD MEMBER foreman_user2;
ALTER ROLE Foreman ADD MEMBER foreman_user3;
ALTER ROLE Client ADD MEMBER client_user2;
ALTER ROLE Client ADD MEMBER client_user3;
ALTER ROLE ProcurementManager ADD MEMBER proc_user2;
ALTER ROLE ProcurementManager ADD MEMBER proc_user3;
GO

GRANT SELECT, UPDATE ON dbo.Projects TO Client;
GRANT SELECT, UPDATE ON dbo.Materials TO ProcurementManager;
GO


SELECT r.name AS RoleName, m.name AS MemberName
FROM sys.database_role_members rm
JOIN sys.database_principals r ON r.principal_id = rm.role_principal_id
JOIN sys.database_principals m ON m.principal_id = rm.member_principal_id
WHERE r.name IN ('Admin','Foreman','Client','ProcurementManager')
ORDER BY r.name, m.name;
GO