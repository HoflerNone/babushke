USE master;
GO
-- ���������: Full + FG_Materials + Log
BACKUP DATABASE Stroika TO DISK = 'C:\Kashin\Backup\Strat_Full.bak' WITH INIT, NAME = 'Strat Full', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\Strat_Full.bak';
GO
BACKUP DATABASE Stroika FILEGROUP = 'FG_Materials' TO DISK = 'C:\Kashin\Backup\Strat_FGM.bak' WITH INIT, NAME = 'Strat FGM', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\Strat_FGM.bak';
GO
BACKUP LOG Stroika TO DISK = 'C:\Kashin\Backup\Strat_Log.trn' WITH INIT, NAME = 'Strat Log', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\Strat_Log.trn';
GO