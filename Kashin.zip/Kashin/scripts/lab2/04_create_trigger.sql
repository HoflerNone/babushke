USE Stroika;
GO
-- ����� �������� ���������� (ProjectsMaterials)
CREATE TRIGGER trg_ProjectsMaterials_Audit
ON dbo.ProjectsMaterials
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- INSERT
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, NewValue, UserName)
    SELECT N'ProjectsMaterials', N'INSERT', i.project_id, 
           CONCAT(N'MaterialID=', i.material_id, N'; Value=', i.material_value),
           SUSER_SNAME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.project_id = i.project_id AND d.material_id = i.material_id);

    -- DELETE
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, OldValue, UserName)
    SELECT N'ProjectsMaterials', N'DELETE', d.project_id, 
           CONCAT(N'MaterialID=', d.material_id, N'; Value=', d.material_value),
           SUSER_SNAME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.project_id = d.project_id AND i.material_id = d.material_id);

    -- UPDATE (��������/����������)
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, OldValue, NewValue, UserName)
    SELECT N'ProjectsMaterials', N'UPDATE', i.project_id,
           CONCAT(N'MaterialID=', d.material_id, N'; OldVal=', d.material_value),
           CONCAT(N'MaterialID=', i.material_id, N'; NewVal=', i.material_value),
           SUSER_SNAME()
    FROM inserted i
    JOIN deleted d ON i.project_id = d.project_id AND i.material_id = d.material_id;
END;
GO

-- ����� ���������� ������ ����� (Projects)
CREATE TRIGGER trg_Projects_StepAudit
ON dbo.Projects
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- INSERT
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, NewValue, UserName)
    SELECT N'Projects', N'INSERT', i.id, 
           CONCAT(N'StepID=', i.step_id, N'; Cost=', i.estimated_cost),
           SUSER_SNAME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    -- DELETE
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, OldValue, UserName)
    SELECT N'Projects', N'DELETE', d.id, 
           CONCAT(N'StepID=', d.step_id, N'; Cost=', d.estimated_cost),
           SUSER_SNAME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);

    -- UPDATE (����� �����)
    INSERT INTO dbo.Audit (TableName, OperationType, RecordID, OldValue, NewValue, UserName)
    SELECT N'Projects', N'UPDATE', i.id,
           CONCAT(N'OldStep=', d.step_id),
           CONCAT(N'NewStep=', i.step_id),
           SUSER_SNAME()
    FROM inserted i
    JOIN deleted d ON i.id = d.id
    WHERE i.step_id <> d.step_id OR i.estimated_cost <> d.estimated_cost;
END;
GO
SELECT name FROM sys.triggers WHERE name LIKE 'trg_%' ORDER BY name;
GO