USE Stroika;
GO

DELETE FROM dbo.ProjectsMaterials WHERE project_id IN (SELECT id FROM dbo.Projects WHERE step_id >= 1);
GO

DELETE FROM dbo.Projects WHERE step_id >= 1;
GO

USE Stroika;
GO
SELECT COUNT(*) AS ActiveProjects FROM dbo.Projects WHERE step_id >= 1;
GO

USE master;
GO
BACKUP LOG Stroika TO DISK = 'C:\Kashin\Backup\Fail2_Tail.trn' WITH NO_TRUNCATE, INIT;
GO
RESTORE DATABASE Stroika FROM DISK = 'C:\Kashin\Backup\S11_Full.bak' WITH REPLACE, NORECOVERY;
GO
RESTORE DATABASE Stroika FROM DISK = 'C:\Kashin\Backup\S11_Diff.bak' WITH NORECOVERY;
GO
RESTORE LOG Stroika FROM DISK = 'C:\Kashin\Backup\S11_Log.trn' WITH NORECOVERY;
GO

RESTORE LOG Stroika FROM DISK = 'C:\Kashin\Backup\Fail2_Tail.trn' WITH STOPAT = '2026-11-11 13:22:57', RECOVERY;
GO

USE Stroika;
GO
SELECT COUNT(*) AS ActiveProjects FROM dbo.Projects WHERE step_id >= 1;
GO