USE master;
GO
BACKUP DATABASE Stroika TO DISK = 'C:\Kashin\Backup\S1_Full.bak' WITH INIT, NAME = 'S1 Full', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\S1_Full.bak';
GO
USE Stroika;
DECLARE @i INT = 1; WHILE @i <= 20 BEGIN INSERT INTO dbo.Materials (material_name, material_value, price) VALUES ('M_S1_' + CAST(@i AS VARCHAR), 10, 10); SET @i += 1; END
WHILE @i <= 30 BEGIN UPDATE dbo.Projects SET estimated_cost = estimated_cost + 1 WHERE id = (@i % 25) + 1; SET @i += 1; END
DELETE TOP (10) FROM dbo.Materials WHERE material_name LIKE 'M_S1_%';
GO
USE master;
BACKUP DATABASE Stroika TO DISK = 'C:\Kashin\Backup\S1_Diff1.bak' WITH DIFFERENTIAL, INIT, NAME = 'S1 Diff1', STATS = 10;
RESTORE VERIFYONLY FROM DISK = 'C:\Kashin\Backup\S1_Diff1.bak';
GO