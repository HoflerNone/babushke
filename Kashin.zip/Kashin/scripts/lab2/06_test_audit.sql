USE Stroika;
GO
EXECUTE AS LOGIN = 'admin_user'; 
UPDATE dbo.Projects SET step_id = 2 WHERE id = 1;
REVERT
EXECUTE AS LOGIN = 'foreman_user'; 
EXEC dbo.UpdateMaterials 1, 1, '������ �500, ��', 1; 
REVERT
EXECUTE AS LOGIN = 'client_user'; 
UPDATE dbo.Projects SET step_id = 3 WHERE id = 2;
REVERT

EXECUTE AS LOGIN = 'procurement_user';
UPDATE dbo.Materials SET material_value = 100 WHERE id = 1; 
REVERT

SELECT AuditID, TableName, OperationType, RecordID, UserName, EventTime, LEFT(NewValue, 80) AS NewValuePreview
FROM dbo.Audit
ORDER BY AuditID;
GO