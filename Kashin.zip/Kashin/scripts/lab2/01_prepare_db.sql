USE master;
GO
ALTER DATABASE Stroika SET RECOVERY FULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.filegroups WHERE name = 'FG_Audit')
BEGIN
    ALTER DATABASE Stroika ADD FILEGROUP FG_Audit;
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_files WHERE name = 'Stroika_Audit')
BEGIN
    ALTER DATABASE Stroika 
    ADD FILE (
        NAME = 'Stroika_Audit',
        FILENAME = 'C:\Kashin\Data\Stroika_Audit.ndf',
        SIZE = 5MB,
        MAXSIZE = 50MB,
        FILEGROWTH = 5MB
    ) TO FILEGROUP FG_Audit;
END
GO