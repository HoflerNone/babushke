USE Stroika;
GO
REVOKE SELECT, INSERT, UPDATE, DELETE ON dbo.Audit FROM Admin, Foreman, Client, ProcurementManager;
GO
GRANT SELECT ON dbo.Audit TO Admin;
GRANT INSERT ON dbo.Audit TO Admin;
DENY UPDATE, DELETE ON dbo.Audit TO Admin;
GO
GRANT INSERT ON dbo.Audit TO Foreman;
DENY SELECT, UPDATE, DELETE ON dbo.Audit TO Foreman;
GO
GRANT INSERT ON dbo.Audit TO Client;
DENY SELECT, UPDATE, DELETE ON dbo.Audit TO Client;
GO
GRANT INSERT ON dbo.Audit TO ProcurementManager;
DENY SELECT, UPDATE, DELETE ON dbo.Audit TO ProcurementManager;
GO
SELECT p.name AS PrincipalName, perm.permission_name AS PermissionName, perm.state_desc AS StateDesc
FROM sys.database_permissions perm
JOIN sys.database_principals p ON p.principal_id = perm.grantee_principal_id
WHERE perm.major_id = OBJECT_ID('dbo.Audit')
AND p.name IN ('Admin','Foreman','Client','ProcurementManager')
ORDER BY p.name, perm.permission_name;
GO