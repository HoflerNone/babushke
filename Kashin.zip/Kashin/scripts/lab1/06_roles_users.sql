USE master;
GO

CREATE LOGIN admin_user WITH PASSWORD = 'AdminPass123!';
CREATE LOGIN foreman_user WITH PASSWORD = 'ForemanPass123!';
CREATE LOGIN client_user WITH PASSWORD = 'ClientPass123!';
CREATE LOGIN procurement_user WITH PASSWORD = 'ProcurementPass123!';
GO

USE Stroika;
GO

CREATE USER admin_user FOR LOGIN admin_user;
CREATE USER foreman_user FOR LOGIN foreman_user;
CREATE USER client_user FOR LOGIN client_user;
CREATE USER procurement_user FOR LOGIN procurement_user;
GO

CREATE ROLE Admin;
CREATE ROLE Foreman;
CREATE ROLE Client;
CREATE ROLE ProcurementManager;
GO

ALTER ROLE Admin ADD MEMBER admin_user;
ALTER ROLE Foreman ADD MEMBER foreman_user;
ALTER ROLE Client ADD MEMBER client_user;
ALTER ROLE ProcurementManager ADD MEMBER procurement_user;
GO

GRANT CONTROL ON DATABASE::Stroika TO Admin;
GO

GRANT EXECUTE ON dbo.UpdateMaterials TO Foreman;
GRANT SELECT ON dbo.vw_ForemanProjects TO Foreman;
DENY SELECT, INSERT, UPDATE, DELETE ON dbo.Projects TO Foreman;
GO

GRANT SELECT ON dbo.vw_ClientProjects TO Client;
GRANT EXECUTE ON dbo.CheckStatus TO Client;
DENY SELECT, INSERT, UPDATE, DELETE ON dbo.Projects TO Client;
GO

GRANT INSERT, UPDATE, SELECT ON dbo.Materials TO ProcurementManager;
GRANT INSERT, UPDATE, SELECT ON dbo.Contractor TO ProcurementManager;
DENY SELECT, INSERT, UPDATE, DELETE ON dbo.Projects TO ProcurementManager;
DENY SELECT, INSERT, UPDATE, DELETE ON dbo.ProjectsMaterials TO ProcurementManager;
GO