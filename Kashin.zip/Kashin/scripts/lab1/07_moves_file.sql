USE master;
GO

ALTER DATABASE Stroika SET OFFLINE WITH ROLLBACK IMMEDIATE;
GO

ALTER DATABASE Stroika MODIFY FILE (NAME = 'Projects', FILENAME = 'C:\Kashin\Data\Moved\Projects.mdf');
ALTER DATABASE Stroika MODIFY FILE (NAME = 'Steps', FILENAME = 'C:\Kashin\Data\Moved\Steps.ndf');
ALTER DATABASE Stroika MODIFY FILE (NAME = 'Materials', FILENAME = 'C:\Kashin\Data\Moved\Materials.ndf');
ALTER DATABASE Stroika MODIFY FILE (NAME = 'ProjectMaterials', FILENAME = 'C:\Kashin\Data\Moved\PMaterials.ndf');
ALTER DATABASE Stroika MODIFY FILE (NAME = 'Contractor', FILENAME = 'C:\Kashin\Data\Moved\Contractors.ndf');
ALTER DATABASE Stroika MODIFY FILE (NAME = 'Logs', FILENAME = 'C:\Kashin\Log\Moved\Stroika.ldf');
GO

ALTER DATABASE Stroika SET ONLINE;
GO

SELECT name, physical_name FROM sys.master_files WHERE database_id = DB_ID('Stroika');
GO