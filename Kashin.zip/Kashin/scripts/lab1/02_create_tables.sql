DROP DATABASE Stroika;
GO

CREATE TABLE dbo.Steps (
    id INT IDENTITY(1,1) NOT NULL,
    steps_description NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Steps PRIMARY KEY CLUSTERED (id) ON [PRIMARY]
) ON [PRIMARY];
GO


CREATE TABLE dbo.Contractor (
    id INT IDENTITY(1,1) NOT NULL,
    contractor_name NVARCHAR(100) NOT NULL,
    takenproject_id INT NULL,
    CONSTRAINT PK_Contractor PRIMARY KEY CLUSTERED (id) ON FG_Other
) ON FG_Other;
GO


CREATE TABLE dbo.Materials (
    id INT IDENTITY(1,1) NOT NULL,
    material_name NVARCHAR(100) NOT NULL,
    material_value INT NOT NULL DEFAULT 0,
    price DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_Materials PRIMARY KEY CLUSTERED (id) ON FG_Materials,
    CONSTRAINT CK_Materials_Price CHECK (price > 0)
) ON FG_Materials;
GO

-- �������
CREATE TABLE dbo.Foreman (
    id INT IDENTITY(1,1) NOT NULL,
    foreman_name NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Foreman PRIMARY KEY CLUSTERED (id) ON FG_Other
) ON FG_Other;
GO


CREATE TABLE dbo.Client (
    id INT IDENTITY(1,1) NOT NULL,
    client_name NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Client PRIMARY KEY CLUSTERED (id) ON FG_Other
) ON FG_Other;
GO


CREATE TABLE dbo.Projects (
    id INT IDENTITY(1,1) NOT NULL,
    contractor_id INT NOT NULL,
    step_id INT NOT NULL,
    estimated_cost DECIMAL(18,2) NOT NULL,
    client_id INT NOT NULL,
    foreman_id INT NOT NULL,
    data_s DATE NOT NULL DEFAULT GETDATE(), 
    data_c DATE NULL,                       
    CONSTRAINT PK_Projects PRIMARY KEY CLUSTERED (id) ON [PRIMARY],
    CONSTRAINT FK_Projects_Contractor FOREIGN KEY (contractor_id) REFERENCES dbo.Contractor(id),
    CONSTRAINT FK_Projects_Step FOREIGN KEY (step_id) REFERENCES dbo.Steps(id),
    CONSTRAINT FK_Projects_Client FOREIGN KEY (client_id) REFERENCES dbo.Client(id),
    CONSTRAINT FK_Projects_Foreman FOREIGN KEY (foreman_id) REFERENCES dbo.Foreman(id),
    CONSTRAINT CK_Projects_Cost CHECK (estimated_cost > 0) 
) ON [PRIMARY];
GO


CREATE TABLE dbo.ProjectsMaterials (
    project_id INT NOT NULL,
    material_id INT NOT NULL,
    material_value INT NOT NULL DEFAULT 0,
    CONSTRAINT PK_ProjectsMaterials PRIMARY KEY CLUSTERED (project_id, material_id) ON FG_Materials,
    CONSTRAINT FK_PM_Project FOREIGN KEY (project_id) REFERENCES dbo.Projects(id),
    CONSTRAINT FK_PM_Material FOREIGN KEY (material_id) REFERENCES dbo.Materials(id),
    CONSTRAINT CK_PM_Value CHECK (material_value >= 0)
) ON FG_Materials;
GO