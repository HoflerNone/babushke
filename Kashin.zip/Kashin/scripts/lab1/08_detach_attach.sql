USE master;
GO

ALTER DATABASE Stroika SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
EXEC sp_detach_db @dbname = N'Stroika';
GO

CREATE DATABASE Stroika
ON 
(FILENAME = 'C:\Kashin\Data\Attach\Projects.mdf'),
(FILENAME = 'C:\Kashin\Data\Attach\Steps.ndf'),
(FILENAME = 'C:\Kashin\Data\Attach\Materials.ndf'),
(FILENAME = 'C:\Kashin\Data\Attach\PMaterials.ndf'),
(FILENAME = 'C:\Kashin\Data\Attach\Contractors.ndf'),
(FILENAME = 'C:\Kashin\Log\Attach\Stroika.ldf')
FOR ATTACH;
GO

ALTER DATABASE Stroika SET MULTI_USER;
GO