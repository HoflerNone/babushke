USE Stroika;
GO

CREATE NONCLUSTERED INDEX IX_Steps_steps_description ON dbo.Steps (steps_description) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_Contractor_contractor_name ON dbo.Contractor (contractor_name) ON [PRIMARY];
GO
CREATE NONCLUSTERED INDEX IX_Contractor_takenproject_id ON dbo.Contractor (takenproject_id) ON [PRIMARY];
GO
CREATE NONCLUSTERED INDEX IX_Materials_material_name ON dbo.Materials (material_name) ON [PRIMARY];
GO
CREATE NONCLUSTERED INDEX IX_Foreman_foreman_name ON dbo.Foreman (foreman_name) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_Client_client_name ON dbo.Client (client_name) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_Projects_contractor_id ON dbo.Projects (contractor_id) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_Projects_step_id ON dbo.Projects (step_id) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_Projects_client_id ON dbo.Projects (client_id) ON FG_Materials;
GO
CREATE NONCLUSTERED INDEX IX_Projects_foreman_id ON dbo.Projects (foreman_id) ON FG_Materials;
GO
CREATE NONCLUSTERED INDEX IX_Projects_data_s ON dbo.Projects (data_s) ON FG_Other;
GO
CREATE NONCLUSTERED INDEX IX_ProjectsMaterials_project_id ON dbo.ProjectsMaterials (project_id) ON [PRIMARY];
GO
CREATE NONCLUSTERED INDEX IX_ProjectsMaterials_material_id ON dbo.ProjectsMaterials (material_id) ON [PRIMARY];
GO